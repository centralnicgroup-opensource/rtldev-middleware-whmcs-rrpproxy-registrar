<?php

$extensions['X-TRAVEL-INDUSTRY'] =  $params["additionalfields"]['.TRAVEL Usage Agreement'] ? 'Y' : 'N';
