<?php

$extensions['X-ACCEPT-QUARANTINE'] = "1";
$extensions['X-EU-ACCEPT-TRUSTEE-TAC'] = "0";
$extensions['X-EU-REGISTRANT-LANG'] = "EN";
