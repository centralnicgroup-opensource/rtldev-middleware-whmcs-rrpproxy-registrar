<?php
$extensions['X-DE-ACCEPT-TRUSTEE-TAC'] = 0;
