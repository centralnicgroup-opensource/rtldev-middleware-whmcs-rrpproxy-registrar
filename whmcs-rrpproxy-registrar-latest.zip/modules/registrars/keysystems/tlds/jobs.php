<?php

$extensions['X-JOBS-COMPANYURL'] = $params["additionalfields"]['Website'];
