<?php

$extensions['X-EU-REGISTRANT-CITIZENSHIP'] = $params["additionalfields"]["X-EU-REGISTRANT-CITIZENSHIP"];
$extensions['X-EU-ACCEPT-TRUSTEE-TAC'] = "0";
$extensions['X-EU-REGISTRANT-LANG'] = "EN";
