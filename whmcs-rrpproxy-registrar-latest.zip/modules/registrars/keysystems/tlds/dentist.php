<?php

$extensions['X-UNITEDTLD-REGULATORY-DATA'] = $params["additionalfields"]['Regulatory Data'];
