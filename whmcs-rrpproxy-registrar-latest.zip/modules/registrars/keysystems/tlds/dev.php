<?php

$extensions['X-ACCEPT-SSL-REQUIREMENT'] = $params["additionalfields"]['.DEV SSL Agreement'] ? 1 : 0;
