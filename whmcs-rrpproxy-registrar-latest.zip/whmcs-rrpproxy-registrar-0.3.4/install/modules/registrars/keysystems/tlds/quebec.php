<?php

$extensions['X-INTENDED-USE'] = $params["additionalfields"]['Intended Use'];
